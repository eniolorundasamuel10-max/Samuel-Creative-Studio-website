/* =========================================================
   SITE SETTINGS  (the only file you need for contact setup)
   ========================================================= */
window.SITE_CONFIG = {
  email: "eniolorundasamuel10@gmail.com",
  whatsappNumber: "2348063728589",   // digits only, with country code

  // CONTACT FORM SETUP
  // The form cannot send messages by itself. To make it work:
  //   1. Create a free account at https://formspree.io
  //   2. Create a new form and use eniolorundasamuel10@gmail.com as the destination
  //   3. Copy the form URL, which looks like: https://formspree.io/f/abcdwxyz
  //   4. Paste it between the quotes below, then save and re-publish.
  // Until you do this, the form will honestly tell visitors to use Email or WhatsApp.
  formEndpoint: ""
};
