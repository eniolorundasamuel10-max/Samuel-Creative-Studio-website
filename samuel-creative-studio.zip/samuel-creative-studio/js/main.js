/* =========================================================
   Samuel Creative Studio - site behaviour
   Sections: 1 Menu  2 Header & active link  3 Reveal  4 Portfolio
             5 Project viewer  6 Service shortcuts  7 Contact form
   ========================================================= */
(function () {
  "use strict";

  var cfg = window.SITE_CONFIG || {};
  var data = window.PORTFOLIO || { categories: [], projects: [] };

  function $(sel, root) { return (root || document).querySelector(sel); }
  function $all(sel, root) { return Array.prototype.slice.call((root || document).querySelectorAll(sel)); }
  function el(tag, cls, text) {
    var n = document.createElement(tag);
    if (cls) n.className = cls;
    if (text) n.textContent = text;
    return n;
  }

  /* ---------- Footer year ---------- */
  var yr = $("#year");
  if (yr) yr.textContent = new Date().getFullYear();

  /* ---------- 1. Mobile menu ---------- */
  var header = $(".site-header");
  var toggle = $(".nav-toggle");
  var nav = $("#site-nav");

  function setMenu(open) {
    nav.classList.toggle("open", open);
    toggle.setAttribute("aria-expanded", String(open));
    toggle.setAttribute("aria-label", open ? "Close menu" : "Open menu");
    document.body.classList.toggle("menu-open", open);
  }
  toggle.addEventListener("click", function () {
    setMenu(toggle.getAttribute("aria-expanded") !== "true");
  });
  $all("a", nav).forEach(function (a) { a.addEventListener("click", function () { setMenu(false); }); });
  document.addEventListener("keydown", function (e) {
    if (e.key === "Escape" && nav.classList.contains("open")) { setMenu(false); toggle.focus(); }
  });
  window.addEventListener("resize", function () { if (window.innerWidth > 920) setMenu(false); });

  /* ---------- 2. Header style and active link ---------- */
  function onScroll() { header.classList.toggle("scrolled", window.scrollY > 20); }
  onScroll();
  window.addEventListener("scroll", onScroll, { passive: true });

  var navLinks = $all("a[data-nav]");
  if ("IntersectionObserver" in window) {
    var spy = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (!en.isIntersecting) return;
        navLinks.forEach(function (a) {
          var on = a.getAttribute("href") === "#" + en.target.id;
          a.classList.toggle("active", on);
          if (on) a.setAttribute("aria-current", "true"); else a.removeAttribute("aria-current");
        });
      });
    }, { rootMargin: "-45% 0px -50% 0px" });
    ["home", "about", "services", "programs", "portfolio", "contact"].forEach(function (id) {
      var s = document.getElementById(id);
      if (s) spy.observe(s);
    });
  }

  /* ---------- 3. Scroll reveal ---------- */
  var reveals = $all(".reveal");
  if ("IntersectionObserver" in window) {
    var io = new IntersectionObserver(function (entries) {
      entries.forEach(function (en) {
        if (en.isIntersecting) { en.target.classList.add("in"); io.unobserve(en.target); }
      });
    }, { threshold: 0.12 });
    reveals.forEach(function (r) { io.observe(r); });
  } else {
    reveals.forEach(function (r) { r.classList.add("in"); });
  }

  /* ---------- 4. Portfolio gallery ---------- */
  var filtersBox = $("#filters");
  var gallery = $("#gallery");
  var current = "All";
  var visible = [];

  function renderFilters() {
    filtersBox.textContent = "";
    ["All"].concat(data.categories).forEach(function (cat) {
      var b = el("button", "filter-btn", cat);
      b.type = "button";
      b.setAttribute("aria-pressed", String(cat === current));
      b.addEventListener("click", function () { current = cat; renderFilters(); renderGallery(); });
      filtersBox.appendChild(b);
    });
  }

  function renderGallery() {
    visible = data.projects.filter(function (p) { return current === "All" || p.category === current; });
    gallery.textContent = "";
    visible.forEach(function (p, i) {
      var b = el("button", "work");
      b.type = "button";
      b.setAttribute("aria-label", "View project: " + p.title);
      b.style.animationDelay = (i * 50) + "ms";
      var img = el("img");
      img.src = p.image; img.alt = p.alt || p.title;
      img.width = 800; img.height = 600; img.loading = "lazy"; img.decoding = "async";
      b.appendChild(img);
      if (p.sample) b.appendChild(el("span", "badge", "Sample concept"));
      var info = el("div", "work-info");
      info.appendChild(el("h3", "", p.title));
      info.appendChild(el("span", "", p.category));
      b.appendChild(info);
      b.addEventListener("click", function () { openViewer(i); });
      gallery.appendChild(b);
    });
  }

  if (filtersBox && gallery) { renderFilters(); renderGallery(); }

  /* ---------- 5. Project viewer ---------- */
  var viewer = $("#viewer");
  var index = 0;
  var lastFocus = null;

  function fillViewer() {
    var p = visible[index];
    if (!p) return;
    var img = $("#viewer-img");
    img.src = p.image; img.alt = p.alt || p.title;
    $("#viewer-title").textContent = p.title;
    $("#viewer-cat").textContent = p.category;
    $("#viewer-desc").textContent = p.description || "";
    $("#viewer-badge").textContent = p.sample ? "Sample concept, not client work" : "";
  }
  function openViewer(i) {
    index = i; fillViewer();
    lastFocus = document.activeElement;
    if (typeof viewer.showModal === "function") viewer.showModal(); else viewer.setAttribute("open", "");
    document.body.classList.add("menu-open");
  }
  function closeViewer() {
    if (typeof viewer.close === "function") viewer.close(); else viewer.removeAttribute("open");
  }
  function step(d) {
    if (!visible.length) return;
    index = (index + d + visible.length) % visible.length; fillViewer();
  }
  if (viewer) {
    $(".viewer-close", viewer).addEventListener("click", closeViewer);
    $("#viewer-prev").addEventListener("click", function () { step(-1); });
    $("#viewer-next").addEventListener("click", function () { step(1); });
    $("#viewer-cta").addEventListener("click", closeViewer);
    viewer.addEventListener("click", function (e) { if (e.target === viewer) closeViewer(); });
    viewer.addEventListener("close", function () {
      document.body.classList.remove("menu-open");
      if (lastFocus && lastFocus.focus) lastFocus.focus();
    });
    viewer.addEventListener("keydown", function (e) {
      if (e.key === "ArrowRight") step(1);
      if (e.key === "ArrowLeft") step(-1);
    });
  }

  /* ---------- 6. "Discuss this project" pre-selects the service ---------- */
  var serviceSelect = $("#f-service");
  $all("[data-service]").forEach(function (a) {
    a.addEventListener("click", function () {
      if (serviceSelect) serviceSelect.value = a.getAttribute("data-service");
    });
  });

  /* ---------- 7. Contact form ---------- */
  var form = $("#contact-form");
  var note = $("#form-note");
  var status = $("#form-status");
  var hasEndpoint = !!(cfg.formEndpoint && cfg.formEndpoint.indexOf("http") === 0);

  if (form && !hasEndpoint && note) {
    note.textContent = "Note: this form is not connected to an inbox yet. For now, please use the Email or WhatsApp buttons.";
  }

  function setStatus(msg, kind) {
    status.className = "status" + (kind ? " " + kind : "");
    status.textContent = msg;
  }

  function whatsappLink(fd) {
    var text = "Hello Samuel, I'm " + fd.get("name") + ". I need: " + fd.get("service") + ". " + fd.get("message");
    return "https://wa.me/" + (cfg.whatsappNumber || "2348063728589") + "?text=" + encodeURIComponent(text);
  }

  if (form) {
    form.addEventListener("submit", function (e) {
      e.preventDefault();
      setStatus("", "");
      if (!form.checkValidity()) {
        form.reportValidity();
        setStatus("Please fill in every field with a valid email address.", "err");
        return;
      }
      var fd = new FormData(form);

      if (!hasEndpoint) {
        status.className = "status err";
        status.textContent = "";
        status.appendChild(document.createTextNode("This form is not connected yet, so nothing was sent. Please "));
        var w = el("a", "", "send your message on WhatsApp");
        w.href = whatsappLink(fd); w.target = "_blank"; w.rel = "noopener noreferrer";
        status.appendChild(w);
        status.appendChild(document.createTextNode(" or email "));
        var m = el("a", "", cfg.email || "eniolorundasamuel10@gmail.com");
        m.href = "mailto:" + (cfg.email || "eniolorundasamuel10@gmail.com");
        status.appendChild(m);
        status.appendChild(document.createTextNode("."));
        return;
      }

      var btn = $("button[type=submit]", form);
      btn.disabled = true; setStatus("Sending...", "");
      fetch(cfg.formEndpoint, { method: "POST", body: fd, headers: { Accept: "application/json" } })
        .then(function (r) {
          if (!r.ok) throw new Error("bad response");
          form.reset();
          setStatus("Thank you. Your message was sent and I will reply soon.", "ok");
        })
        .catch(function () {
          setStatus("Sorry, the message could not be sent. Please use Email or WhatsApp instead.", "err");
        })
        .then(function () { btn.disabled = false; });
    });
  }
})();
