/* =========================================================
   PORTFOLIO DATA  -  edit this file to change your projects.

   TO REPLACE A SAMPLE WITH REAL WORK:
   1. Put your image in assets/images/  (JPG, PNG or WebP, ideally 1600px wide
      or smaller; compress it first at squoosh.app so the site stays fast).
   2. Change "image" to your file name, e.g. "assets/images/my-logo.jpg".
   3. Change "title", "category" and "description".
   4. Change  sample: true  to  sample: false  so the "Sample concept" label goes away.

   TO ADD A PROJECT: copy one block { ... }, paste it with a comma, and edit it.
   TO REMOVE ONE: delete its whole { ... } block.
   "category" must match one of the names in "categories" below.
   ========================================================= */
window.PORTFOLIO = {
  categories: [
    "Logos and Brand Identity",
    "Flyers and Posters",
    "Social Media Designs",
    "Advertising Creatives",
    "Website Designs"
  ],
  projects: [
    {
      title: "Monogram Logo Concept",
      category: "Logos and Brand Identity",
      image: "assets/images/logo-monogram.svg",
      alt: "Sample logo concept with a violet monogram mark",
      description: "A sample logo concept showing a simple monogram mark with a clean wordmark. Replace with a real logo project.",
      sample: true
    },
    {
      title: "Brand Identity Board",
      category: "Logos and Brand Identity",
      image: "assets/images/brand-board.svg",
      alt: "Sample brand identity board with logo, colour palette and typography",
      description: "A sample brand board showing a logo, colour palette and type pairing. Replace with a real identity project.",
      sample: true
    },
    {
      title: "Event Poster Concept",
      category: "Flyers and Posters",
      image: "assets/images/poster-event.svg",
      alt: "Sample event poster concept with bold typography",
      description: "A sample event poster concept built around bold type and strong shapes. Replace with a real poster.",
      sample: true
    },
    {
      title: "Promo Flyer Concept",
      category: "Flyers and Posters",
      image: "assets/images/flyer-promo.svg",
      alt: "Sample promotional flyer concept with a bright orange and rose palette",
      description: "A sample promotional flyer concept with a clear offer and call to action. Replace with a real flyer.",
      sample: true
    },
    {
      title: "Social Post Set Concept",
      category: "Social Media Designs",
      image: "assets/images/social-set.svg",
      alt: "Sample set of three matching social media posts",
      description: "A sample set of matching social posts that keep one consistent look. Replace with real social media work.",
      sample: true
    },
    {
      title: "Story and Post Concept",
      category: "Social Media Designs",
      image: "assets/images/social-story.svg",
      alt: "Sample story and square post layout",
      description: "A sample story and square post pairing for a campaign. Replace with real social media work.",
      sample: true
    },
    {
      title: "Web Banner Ad Concept",
      category: "Advertising Creatives",
      image: "assets/images/ad-banner.svg",
      alt: "Sample wide web banner advertisement concept",
      description: "A sample wide banner ad concept with a headline, offer and button. Replace with a real ad creative.",
      sample: true
    },
    {
      title: "Product Promo Ad Concept",
      category: "Advertising Creatives",
      image: "assets/images/ad-promo.svg",
      alt: "Sample product promotion advertisement concept",
      description: "A sample promotional ad concept focused on one clear offer. Replace with a real ad creative.",
      sample: true
    },
    {
      title: "Landing Page Concept",
      category: "Website Designs",
      image: "assets/images/web-landing.svg",
      alt: "Sample landing page design shown in a browser window",
      description: "A sample landing page layout with a hero, headline and call to action. Replace with a real website design.",
      sample: true
    },
    {
      title: "Website and Mobile Concept",
      category: "Website Designs",
      image: "assets/images/web-mobile.svg",
      alt: "Sample website design shown on desktop and mobile",
      description: "A sample website layout shown on desktop and phone. Replace with a real website design.",
      sample: true
    }
  ]
};
